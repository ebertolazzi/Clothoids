.. meta::94998660c78eb26ba264b2e96fd30917ee9a4df0ef079b3615996308f9d54681d3c894ffcf650bc38c294cbbae04fe2fa045d6f927c9988c8ca9dbb6e1f33e74

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::Dubins &gt; Struct Reference

Dubins &gt; Struct Reference
============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1Dubins_01_4.html
