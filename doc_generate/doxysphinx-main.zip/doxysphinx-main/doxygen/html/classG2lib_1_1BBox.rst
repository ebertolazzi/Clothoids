.. meta::e4b304061f5af9122e9c8c4a1a316dda47e5724cd78f0578dc6a79929578c2544fbf7f9b9ce6d934ff3239cb08b4fd52a3d49bb6e375ddf4824b4caf377debf0

:orphan:

.. title:: Clothoids C++ interface: G2lib::BBox Class Reference

BBox Class Reference
====================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1BBox.html
