.. meta::4da7d301cf369924d8648e9519c2f36a645baae2511ad462061a701ccbde3d948a373adf29597120de21777f6676764627c74ce5bdb7d8544cfb91d5d5f49009

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::Triangle2D &gt; Struct Reference

Triangle2D &gt; Struct Reference
================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1Triangle2D_01_4.html
