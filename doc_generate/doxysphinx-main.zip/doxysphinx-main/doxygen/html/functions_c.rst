.. meta::0a59b9d12678f7ed50aad81bd205f9518343ec6d9dfec2840f4fcea08112467f60d692097c65773a2b77b478cb2121422a22576900c8087c2e923c2117b438d7

:orphan:

.. title:: Clothoids C++ interface: Class Members

Class Members
=============

.. container:: doxygen-content

   
   .. raw:: html
     :file: functions_c.html
