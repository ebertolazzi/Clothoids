.. meta::f3fae079857554a026a92d600586014b161b852b17a22c8c47b89af6ecdbbc7bbe26063e72352498a70c639d3d75d98c68ee359938e9c051f2f7d9abd5190a3b

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::ClothoidSplineG2 &gt; Struct Reference

ClothoidSplineG2 &gt; Struct Reference
======================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1ClothoidSplineG2_01_4.html
