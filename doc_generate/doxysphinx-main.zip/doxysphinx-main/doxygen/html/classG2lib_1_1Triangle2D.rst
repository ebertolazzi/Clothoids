.. meta::38bc7e0904e2fd983eafb3044036859938062e7139f850d5319ff7f4e5e66c5d349cfcae714c37f136cb60d4d0e2860cec2ec8f2b2c453f062cbb69157c7e2bd

:orphan:

.. title:: Clothoids C++ interface: G2lib::Triangle2D Class Reference

Triangle2D Class Reference
==========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1Triangle2D.html
