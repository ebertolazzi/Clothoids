.. meta::afabf013de5dd4d44107d9521505517ac6fb292b197c23cd9c5671dedfa942ee81a05628e1a2cbdf491e6e0f2b548cf485cb735b1f371b4f37d4a3efcf5419f5

:orphan:

.. title:: Clothoids C++ interface: G2lib Namespace Reference

G2lib Namespace Reference
=========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: namespaceG2lib.html
