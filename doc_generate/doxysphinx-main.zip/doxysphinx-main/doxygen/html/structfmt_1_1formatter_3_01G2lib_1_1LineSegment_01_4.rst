.. meta::a63313efa319d1a2d03f89ab47af357668963abd9fe03d1503e0d26ab70022e5279507522f6a7e65d6cae938db62aa37d5276336c5690e4acb36208635239287

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::LineSegment &gt; Struct Reference

LineSegment &gt; Struct Reference
=================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1LineSegment_01_4.html
