.. meta::076cfa6a3ab3f290bafaf192b31c6dc2044a96daa00b9707711fbc433e61ef664c5976978b9b9abc6797c6369200cd25c3bafbfd46713614895d44947442ebc2

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::Dubins3p &gt; Struct Reference

Dubins3p &gt; Struct Reference
==============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1Dubins3p_01_4.html
