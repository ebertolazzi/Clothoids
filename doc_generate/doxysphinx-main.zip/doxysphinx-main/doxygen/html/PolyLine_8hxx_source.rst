.. meta::7aae992d277c812c6cb34b8cd2556ae6b9a5cda35f517195d8d78e22681e8051bf5076dab20c6477caec0d80d0eae80348bc5a83f04f4dea4567e39b3f1fff51

:orphan:

.. title:: Clothoids C++ interface: /Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/PolyLine.hxx Source File

/Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/PolyLine.hxx Source File
==========================================================================================================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: PolyLine_8hxx_source.html
