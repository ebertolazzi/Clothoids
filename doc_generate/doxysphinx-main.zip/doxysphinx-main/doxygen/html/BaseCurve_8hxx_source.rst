.. meta::a1e75d4bed0af4ab2a1b6783d1c05802ab4d454493a103c3bbc9c9864e9a2ed2ef194d6ae0a5ac03db73b21820bad7e16ecce70bee861a34e9da88471ab5ad6b

:orphan:

.. title:: Clothoids C++ interface: /Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/BaseCurve.hxx Source File

/Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/BaseCurve.hxx Source File
===========================================================================================================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: BaseCurve_8hxx_source.html
