.. meta::aea829eacb415aa5e623ce6070315d30c7a9b8d1b86ec6580c08305b1ab91183626549b83ef63932b05bf0dd40342730b0a67d0c1d8795ac499872ef9b14bae5

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::Biarc &gt; Struct Reference

Biarc &gt; Struct Reference
===========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1Biarc_01_4.html
