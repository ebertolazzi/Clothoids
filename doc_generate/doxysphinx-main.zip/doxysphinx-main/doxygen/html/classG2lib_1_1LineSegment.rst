.. meta::2c4fe5ac530490ddf537243af5c06a29dcef8c18f21d1cef8010ab5c988f3908357b2907768837ae5aef5f1827b96539d64168c53f749a13326523233388212d

:orphan:

.. title:: Clothoids C++ interface: G2lib::LineSegment Class Reference

LineSegment Class Reference
===========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1LineSegment.html
