.. meta::3c1f7074e9401f6a02f1d4ed03b72e0af488bc8d291d6c4c0738c4324767da6fcc2e5c0d4848561f4c928ca321e7ad80d206bd69a569b052f8322b7d1a1d0fea

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::BBox &gt; Struct Reference

BBox &gt; Struct Reference
==========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1BBox_01_4.html
