.. meta::b7d36e9692b88d106c4da6cd4b4c21ccf590566ba360b5b6fcc755e669dfada8067c54e6bffe37227fdc5e65295c46677219d0967a9167fe4477f21d9bcad36b

:orphan:

.. title:: Clothoids C++ interface: /Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/Fresnel.hxx Source File

/Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/Fresnel.hxx Source File
=========================================================================================================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: Fresnel_8hxx_source.html
