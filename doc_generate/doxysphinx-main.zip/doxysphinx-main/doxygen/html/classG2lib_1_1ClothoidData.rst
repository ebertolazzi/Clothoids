.. meta::fd3f56dee519b1277b8bd0e898353291275950ee9659bb53f0dc6cecdfbccc48f838da90b5c28ba2cca1bad28a8f1e2e355fd5164ab6e2be6c1f1603d07e100a

:orphan:

.. title:: Clothoids C++ interface: G2lib::ClothoidData Class Reference

ClothoidData Class Reference
============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1ClothoidData.html
