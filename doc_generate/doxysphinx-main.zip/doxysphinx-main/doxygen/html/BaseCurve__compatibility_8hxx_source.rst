.. meta::13b6b19bb13986dfa8d318254de4ba1af4e679365b82448e57db8a9ea4dc76e0594c0581b01e861bc79bcc6dab940f09be4e2e4013763f1645b5a19acf6e432f

:orphan:

.. title:: Clothoids C++ interface: /Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/BaseCurve_compatibility.hxx Source File

/Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/BaseCurve\_compatibility.hxx Source File
==========================================================================================================================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: BaseCurve__compatibility_8hxx_source.html
