.. meta::30fa37576340e971317ad9b81c66a4a9b205a8eefb047aa785cc171eff4cc9e4fc5290aa18b4e5cec624a80fee8eac0380245ddff0da2da86ed4d0ea1456b0e7

:orphan:

.. title:: Clothoids C++ interface: G2lib::G2solve3arc Class Reference

G2solve3arc Class Reference
===========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1G2solve3arc.html
