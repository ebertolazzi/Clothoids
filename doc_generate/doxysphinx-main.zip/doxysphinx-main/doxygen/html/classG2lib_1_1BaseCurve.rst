.. meta::b84593c6116ac57b7413dac917ce3e0b6fcc0e0e3c1fef2d61b1561b950033c9a837ae0e9bd23b43ebbf50102cc35a9041bd8bc7bf721cc0019fa3c5ebc3e359

:orphan:

.. title:: Clothoids C++ interface: G2lib::BaseCurve Class Reference

BaseCurve Class Reference
=========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1BaseCurve.html
