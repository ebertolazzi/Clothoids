.. meta::a68ceffbd0be5fa808d48a0e4438f9b7dd2b16d4ac16f026864ecc29ba9127a9b2897a97b9dfd16351c7f4df4169d3b3eb3b118dc825516f3818a7bff82f1418

:orphan:

.. title:: Clothoids C++ interface: Class Members

Class Members
=============

.. container:: doxygen-content

   
   .. raw:: html
     :file: functions_y.html
