.. meta::0f443f0cb223408c627d52596c5c4181048be57bbe4a01f351fb4579d160ae560cb617c92d707c0e5e0e9674052d23234ab9671a47c9f630fbe0cef75ab1fcbb

:orphan:

.. title:: Clothoids C++ interface: /Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/Biarc_compatibility.hxx Source File

/Users/enrico/Ricerca/develop/PINS/pins-mechatronix/LibSources/submodules/Clothoids/src/Clothoids/Biarc\_compatibility.hxx Source File
======================================================================================================================================

.. container:: doxygen-content

   
   .. raw:: html
     :file: Biarc__compatibility_8hxx_source.html
