.. meta::03a561a31f8314761b0fe0677723954dd600cd8ef40b743fe156821b9f83c7b6cfda0c512a40886c52e92d7a3684a7eaea085b143b90bb12259a9da5fe048934

:orphan:

.. title:: Clothoids C++ interface: G2lib::Dubins Class Reference

Dubins Class Reference
======================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1Dubins.html
