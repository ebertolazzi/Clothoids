.. meta::f566934811aeefa9df2020e8e03411e3825e9568e5c150068fa28022c5f9280876e1928b28a511cfad5b13f57e70ca1279d4aea18260eedbba679d6a81c5b9ef

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::PolyLine &gt; Struct Reference

PolyLine &gt; Struct Reference
==============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1PolyLine_01_4.html
