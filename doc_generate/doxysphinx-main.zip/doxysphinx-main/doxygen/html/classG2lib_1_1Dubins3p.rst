.. meta::460f550dff2db717a2a9a67f673a08918d9b154859bc7c57dd5826e99e02aa1944458336dca8e0f53e1a8c4f10c2158f4ef06f17bf4b240064b7883aed6573b7

:orphan:

.. title:: Clothoids C++ interface: G2lib::Dubins3p Class Reference

Dubins3p Class Reference
========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1Dubins3p.html
