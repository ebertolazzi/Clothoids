.. meta::449a3245f2aa966f3ff584f1e8e4232cf49c66f96e9e71a4f71bd816a942f5290f2ce66c2f3528356189de3ee7219b3baf6c952d49f17e6821f5ad4d2c1aeb5d

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::BiarcList &gt; Struct Reference

BiarcList &gt; Struct Reference
===============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1BiarcList_01_4.html
