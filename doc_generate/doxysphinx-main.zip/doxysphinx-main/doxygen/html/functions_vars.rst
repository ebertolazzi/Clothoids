.. meta::b40d9703da50847dd7479e2e23557f0233f915583cd0b39ee86fb6ae0ad086af622ff21aefea9f916011be1976cc779a0e1c7e434860b4c527e66af714541761

:orphan:

.. title:: Clothoids C++ interface: Class Members - Variables

Class Members - Variables
=========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: functions_vars.html
