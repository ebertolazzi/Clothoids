.. meta::c77b2b63a02a34f7af222e8de575f219f9d3a95562fa0a7c1adb4e36e57c83278c55a80a14f86a142b8a94750230c5f34d1c2db869448ccb8ea0a1b766b33081

:orphan:

.. title:: Clothoids C++ interface: G2lib::Biarc Class Reference

Biarc Class Reference
=====================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1Biarc.html
