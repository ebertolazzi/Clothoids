.. meta::a287cceb70db2bd50e4dcc98dda41b033ab71a08ddae8cbb20573e029600302fcb9d25658a10d1258bb806ae3c19984e7986fbbc42d1689934ef1bc6264a0711

:orphan:

.. title:: Clothoids C++ interface: fmt::formatter&lt; G2lib::CircleArc &gt; Struct Reference

CircleArc &gt; Struct Reference
===============================

.. container:: doxygen-content

   
   .. raw:: html
     :file: structfmt_1_1formatter_3_01G2lib_1_1CircleArc_01_4.html
