.. meta::aa682cbee317a1d50c6283f17e2adb60ee46d654c29f67fb29356d365f38e49f1abb781fde00379e902fbeea5d7cfe32612e3d5ced08895546ad393af105790d

:orphan:

.. title:: Clothoids C++ interface: G2lib::PolyLine Class Reference

PolyLine Class Reference
========================

.. container:: doxygen-content

   
   .. raw:: html
     :file: classG2lib_1_1PolyLine.html
